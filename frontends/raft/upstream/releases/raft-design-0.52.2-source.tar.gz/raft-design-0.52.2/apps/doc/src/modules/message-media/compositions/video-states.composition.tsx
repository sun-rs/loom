import { AlertTriangle, ArrowDownToLine } from "lucide-react";
import { Spinner } from "@botiverse/raft-ui";
import {
  MessageVideoPreview,
  MessageVideoPreviewAction,
  MessageVideoPreviewFailureAction,
  MessageVideoPreviewFailureContent,
  MessageVideoPreviewFailureIcon,
  MessageVideoPreviewFailureTitle,
  MessageVideoPreviewFallback,
  MessageVideoPreviewMedia,
} from "@botiverse/raft-ui";
import {
  MESSAGE_FIXTURE_VIDEO_SRC,
  downloadMessageFixture,
} from "#/modules/message-item/message-item.fixtures.ts";

export type MessageVideoPreviewCompositionProps = {
  name?: string;
  onDownload?: () => void;
  src?: string;
};

export function MessageVideoPreviewComposition({
  name = "demo-recording.webm",
  onDownload = () => downloadMessageFixture("demo-recording.webm"),
  src = MESSAGE_FIXTURE_VIDEO_SRC,
}: MessageVideoPreviewCompositionProps = {}) {
  return (
    <MessageVideoPreview title={name}>
      <MessageVideoPreviewMedia
        aria-label={`Play ${name}`}
        controls
        playsInline
        preload="metadata"
        src={src}
      />
      <MessageVideoPreviewAction
        aria-label={`Download ${name}`}
        title={`Download ${name}`}
        onClick={onDownload}
      >
        <ArrowDownToLine />
      </MessageVideoPreviewAction>
    </MessageVideoPreview>
  );
}

function MessageVideoPendingComposition() {
  return (
    <MessageVideoPreview aria-busy title="demo-recording.mp4">
      <MessageVideoPreviewFallback>
        <Spinner size="md" variant="inverse" />
      </MessageVideoPreviewFallback>
    </MessageVideoPreview>
  );
}

export function MessageVideoPreviewFailedComposition({
  name = "demo-recording.webm",
  reason = "This video may use a codec this browser cannot preview.",
  onDownload = () => downloadMessageFixture("demo-recording.webm"),
}: {
  name?: string;
  reason?: string;
  onDownload?: (() => void) | null;
} = {}) {
  return (
    <MessageVideoPreview title={name}>
      <MessageVideoPreviewFallback>
        <MessageVideoPreviewFailureContent>
          <MessageVideoPreviewFailureIcon>
            <AlertTriangle />
          </MessageVideoPreviewFailureIcon>
          <MessageVideoPreviewFailureTitle>{reason}</MessageVideoPreviewFailureTitle>
          {onDownload ? (
            <MessageVideoPreviewFailureAction onClick={onDownload}>
              <ArrowDownToLine />
              Download to view
            </MessageVideoPreviewFailureAction>
          ) : null}
        </MessageVideoPreviewFailureContent>
      </MessageVideoPreviewFallback>
    </MessageVideoPreview>
  );
}

export function MessageVideoPreviewStatesComposition() {
  return (
    <div className="stack-y-2">
      <MessageVideoPreviewComposition />
      <MessageVideoPendingComposition />
      <MessageVideoPreviewFailedComposition />
    </div>
  );
}
