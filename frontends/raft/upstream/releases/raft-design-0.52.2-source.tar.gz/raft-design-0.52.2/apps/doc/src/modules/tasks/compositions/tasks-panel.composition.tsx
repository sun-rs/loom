import type { ReactNode } from "react";
import { useCallback, useMemo, useRef, useState } from "react";
import {
  SegmentedControl,
  SegmentedControlItem,
  SegmentedControlLabel,
  TasksPanelRoot,
  TasksPanelToolbar,
  TasksPanelToolbarFilters,
  TasksPanelToolbarView,
  TasksPanelViewport,
} from "@botiverse/raft-ui";
import { Columns3, LayoutList } from "lucide-react";

import {
  getTaskStatusLabel,
  moveTaskFixture,
  TASK_FIXTURES,
} from "#/modules/task-card/task-card.fixtures.ts";
import type { TaskFixture, TaskStatus } from "#/modules/task-card/task-card.fixtures.ts";
import { TasksPanelBoardView } from "../tasks-panel-board-view.tsx";
import { TasksPanelEmptyState } from "../tasks-panel-empty-state.tsx";
import { TasksPanelListView } from "../tasks-panel-list-view.tsx";
import { TasksIdentityFiltersComposition } from "./tasks-identity-filters.composition.tsx";

type TaskView = "board" | "list";

export type TasksPanelCompositionProps = {
  tasks?: readonly TaskFixture[];
  toolbarFilters?: ReactNode;
  filterTask?: (task: TaskFixture) => boolean;
  view?: TaskView;
  initialView?: TaskView;
  onViewChange?: (view: TaskView) => void;
  onTasksChange?: (tasks: readonly TaskFixture[]) => void;
  onOpenTask?: (task: TaskFixture) => void;
  blockedDropStatus?: TaskStatus;
  showChannelName?: boolean;
  /** When false, hide the toolbar Board/List control (e.g. mobile page header owns it). */
  showToolbarView?: boolean;
};

export function TasksPanelComposition({
  tasks: controlledTasks,
  toolbarFilters,
  filterTask,
  view: controlledView,
  initialView = "board",
  onViewChange,
  onTasksChange,
  onOpenTask,
  blockedDropStatus,
  showChannelName = false,
  showToolbarView = true,
}: TasksPanelCompositionProps) {
  const portalRef = useRef<HTMLDivElement>(null);
  const [localTasks, setLocalTasks] = useState<readonly TaskFixture[]>(TASK_FIXTURES);
  const [localView, setLocalView] = useState<TaskView>(initialView);
  const [collapsed, setCollapsed] = useState<Record<TaskStatus, boolean>>({
    todo: false,
    "in-progress": false,
    "in-review": false,
    done: true,
    closed: true,
  });
  const [announcement, setAnnouncement] = useState("Ready");

  const tasks = controlledTasks ?? localTasks;
  const visibleTasks = useMemo(
    () => (filterTask ? tasks.filter(filterTask) : tasks),
    [filterTask, tasks],
  );
  const view = controlledView ?? localView;
  const updateTasks = useCallback(
    (nextTasks: readonly TaskFixture[]) => {
      if (controlledTasks === undefined) setLocalTasks(nextTasks);
      onTasksChange?.(nextTasks);
    },
    [controlledTasks, onTasksChange],
  );
  const setView = useCallback(
    (nextView: TaskView) => {
      if (controlledView === undefined) setLocalView(nextView);
      onViewChange?.(nextView);
      setAnnouncement(`${nextView === "board" ? "Board" : "List"} view selected`);
    },
    [controlledView, onViewChange],
  );

  const updateStatus = useCallback(
    (taskId: string, status: TaskStatus) => {
      const task = tasks.find((item) => item.id === taskId);
      if (!task || task.status === status) return;
      updateTasks(moveTaskFixture(tasks, taskId, { status }));
      setAnnouncement(`Task #${task.taskNumber} moved to ${getTaskStatusLabel(status)}`);
    },
    [tasks, updateTasks],
  );
  const moveTask = useCallback(
    (
      taskId: string,
      target: { status: TaskStatus; taskId?: string; placement?: "before" | "after" | null },
    ) => {
      const task = tasks.find((item) => item.id === taskId);
      if (!task) return;
      updateTasks(moveTaskFixture(tasks, taskId, target));
      setAnnouncement(`Task #${task.taskNumber} moved to ${getTaskStatusLabel(target.status)}`);
    },
    [tasks, updateTasks],
  );
  const openTask = useCallback(
    (task: TaskFixture) => {
      onOpenTask?.(task);
      setAnnouncement(`Opened task #${task.taskNumber}: ${task.title}`);
    },
    [onOpenTask],
  );
  const handleCollapsedChange = useCallback((status: TaskStatus, nextOpen: boolean) => {
    setCollapsed((current) => ({ ...current, [status]: !nextOpen }));
  }, []);

  return (
    <div ref={portalRef} className="relative flex size-full min-h-0  min-w-0">
      <TasksPanelRoot aria-label="Tasks panel">
        <TasksPanelToolbar>
          <TasksPanelToolbarFilters>
            {toolbarFilters ?? <TasksIdentityFiltersComposition />}
          </TasksPanelToolbarFilters>
          {showToolbarView ? (
            <TasksPanelToolbarView>
              <SegmentedControl value={view} onValueChange={setView} aria-label="Task view">
                <SegmentedControlItem value="board">
                  <Columns3 aria-hidden />
                  <SegmentedControlLabel className="max-sm:sr-only">Board</SegmentedControlLabel>
                </SegmentedControlItem>
                <SegmentedControlItem value="list">
                  <LayoutList aria-hidden />
                  <SegmentedControlLabel className="max-sm:sr-only">List</SegmentedControlLabel>
                </SegmentedControlItem>
              </SegmentedControl>
            </TasksPanelToolbarView>
          ) : null}
        </TasksPanelToolbar>

        <TasksPanelViewport>
          {tasks.length === 0 ? (
            <TasksPanelEmptyState filtered={false} />
          ) : visibleTasks.length === 0 ? (
            <TasksPanelEmptyState filtered />
          ) : view === "board" ? (
            <TasksPanelBoardView
              tasks={visibleTasks}
              collapsed={collapsed}
              onCollapsedChange={handleCollapsedChange}
              onOpenTask={openTask}
              onStatusChange={updateStatus}
              onMoveTask={moveTask}
              portalRef={portalRef}
              blockedDropStatus={blockedDropStatus}
              showChannelName={showChannelName}
            />
          ) : (
            <TasksPanelListView
              tasks={visibleTasks}
              collapsed={collapsed}
              onCollapsedChange={handleCollapsedChange}
              onOpenTask={openTask}
              onStatusChange={updateStatus}
              portalRef={portalRef}
              showChannelName={showChannelName}
            />
          )}
        </TasksPanelViewport>
      </TasksPanelRoot>

      <span className="sr-only" aria-live="polite">
        {announcement}
      </span>
    </div>
  );
}
