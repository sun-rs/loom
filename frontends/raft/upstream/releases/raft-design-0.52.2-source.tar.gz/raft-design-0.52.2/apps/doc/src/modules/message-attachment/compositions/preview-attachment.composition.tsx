import { useCallback, useState } from "react";
import { Eye } from "lucide-react";
import { Spinner } from "@botiverse/raft-ui";
import {
  MessageAttachmentAction,
  MessageAttachmentCard,
  MessageAttachmentGroup,
  MessageAttachmentMeta,
  MessageAttachmentMetaEnd,
  MessageAttachmentMetaStart,
  MessageAttachmentTitle,
} from "@botiverse/raft-ui";

export function MessageAttachmentPreviewUsageComposition() {
  const [opening, setOpening] = useState(false);

  const handlePreview = useCallback(() => setOpening(true), []);

  return (
    <MessageAttachmentGroup>
      <MessageAttachmentCard aria-busy={opening || undefined}>
        <MessageAttachmentTitle>screening.html</MessageAttachmentTitle>
        <MessageAttachmentMeta>
          <MessageAttachmentMetaStart>44 KB</MessageAttachmentMetaStart>
          <MessageAttachmentMetaEnd>
            {opening ? (
              <Spinner size="xs" />
            ) : (
              <MessageAttachmentAction
                aria-label="Preview screening.html"
                onClick={handlePreview}
                title="Preview screening.html"
              >
                <Eye />
              </MessageAttachmentAction>
            )}
          </MessageAttachmentMetaEnd>
        </MessageAttachmentMeta>
      </MessageAttachmentCard>
    </MessageAttachmentGroup>
  );
}
