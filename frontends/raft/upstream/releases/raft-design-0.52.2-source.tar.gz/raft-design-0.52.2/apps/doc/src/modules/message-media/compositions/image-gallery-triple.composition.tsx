import {
  MessageImageGallery,
  MessageImageGalleryItem,
  MessageImageGalleryMedia,
} from "@botiverse/raft-ui";
import { MESSAGE_FIXTURE_IMAGE_SRC } from "#/modules/message-item/message-item.fixtures.ts";

export function MessageImageGalleryTripleComposition() {
  return (
    <MessageImageGallery>
      <div className="grid grid-cols-2 gap-2">
        <MessageImageGalleryItem className="h-[112px] @min-[22.5rem]/gallery:h-[128px]">
          <MessageImageGalleryMedia>
            <img
              src={MESSAGE_FIXTURE_IMAGE_SRC}
              alt="release poster first crop"
              className="block size-full  object-cover"
            />
          </MessageImageGalleryMedia>
        </MessageImageGalleryItem>
        <MessageImageGalleryItem className="h-[112px] @min-[22.5rem]/gallery:h-[128px]">
          <MessageImageGalleryMedia>
            <img
              src={MESSAGE_FIXTURE_IMAGE_SRC}
              alt="release poster second crop"
              className="block size-full  object-cover"
            />
          </MessageImageGalleryMedia>
        </MessageImageGalleryItem>
        <MessageImageGalleryItem className="h-[112px] @min-[22.5rem]/gallery:h-[128px]">
          <MessageImageGalleryMedia>
            <img
              src={MESSAGE_FIXTURE_IMAGE_SRC}
              alt="release poster third crop"
              className="block size-full  object-cover"
            />
          </MessageImageGalleryMedia>
        </MessageImageGalleryItem>
      </div>
    </MessageImageGallery>
  );
}
