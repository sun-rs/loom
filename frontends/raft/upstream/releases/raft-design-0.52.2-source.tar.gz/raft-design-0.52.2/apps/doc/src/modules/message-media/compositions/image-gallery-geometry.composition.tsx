import {
  MessageImageGallery,
  MessageImageGalleryItem,
  MessageImageGalleryMedia,
} from "@botiverse/raft-ui";

export function MessageImageGalleryGeometryComposition() {
  return (
    <MessageImageGallery>
      <div className="grid grid-cols-1 gap-2">
        <MessageImageGalleryItem className="h-[128px] @min-[22.5rem]/gallery:h-[144px]">
          <MessageImageGalleryMedia>
            <img
              src="/raft-logo.svg"
              alt="Wide Raft logo fixture"
              className="block size-full  object-contain"
            />
          </MessageImageGalleryMedia>
        </MessageImageGalleryItem>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <MessageImageGalleryItem className="h-[128px] @min-[22.5rem]/gallery:h-[144px]">
          <MessageImageGalleryMedia>
            <img
              src="/message-fixtures/tall-diagram.svg"
              alt="Tall diagram fixture"
              className="block size-full  object-contain"
            />
          </MessageImageGalleryMedia>
        </MessageImageGalleryItem>
      </div>
    </MessageImageGallery>
  );
}
