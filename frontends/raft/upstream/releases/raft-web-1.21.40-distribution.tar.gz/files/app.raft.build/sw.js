// Cache name is the asset-cache generation. Bump it when changing cache
// admission rules so activate purges entries written by the old policy.
const ASSET_CACHE = "slock-assets-v2";
const HTML_FALLBACK_CONTENT_TYPE = /\btext\/html\b/i;
const CACHEABLE_ASSET_PATH = /\.(?:css|gif|ico|jpe?g|js|json|mjs|png|svg|webp|woff2?)$/i;
const CACHEABLE_ASSET_TYPES = [
  "application/javascript",
  "application/json",
  "font/",
  "image/",
  "text/css",
];

// The app's HTML, kept so a reopened page paints without waiting for the
// network (docs/frontend/boot-shell.md, "Kept by the service worker"). Its own
// cache: recovery and asset-cache bumps clear it separately.
const SHELL_CACHE = "slock-shell-v1";
const SHELL_KEY = "/";
const SHELL_SAVED_AT = "x-raft-shell-saved-at";
const SHELL_ASSETS = "x-raft-shell-assets";
// Older than this, the network answers first (the copy is still the fallback offline).
const SHELL_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
// Paths the app's HTML never answers: the server's own pages when it shares
// the origin (tests/serviceWorkerShell.test.ts keeps this in step with
// packages/server/src/app.ts), the socket, the daemon, built files.
const NOT_APP_PAGE = /^\/(?:api|internal|oidc|share|health|livez|metrics|socket\.io|daemon|assets|feedback|\.well-known)(?:\/|$)/;
const FILE_PATH = /\/[^/]*\.[a-z0-9]+$/i;
// A release built with RAFT_SHELL_URGENT=1 carries this; see shellUrgent below.
const SHELL_URGENT_META = /<meta name="raft-shell" content="urgent"/;
const SHELL_ASSET_REF = /(?:src|href)="(\/assets\/[^"]+\.(?:js|css))"/g;
// Our HTML, not any 200 text/html (a maintenance page, a CDN challenge, a
// captive portal): the prerendered boot shell and an entry script from /assets.
const SHELL_MARKER = /data-boot-shell=/;
const SHELL_ENTRY = /<script type="module"[^>]*\ssrc="\/assets\/[^"]+\.js"/;

// The display locale's catalog chunks (i18n/messages/index.ts): every
// catalog, en included, is a lazy chunk the boot script modulepreloads from
// the page's JSON map (boot/bootInlineScript.ts), so the HTML names none of
// them as src/href. The page tells the worker its locale (raft:display-locale,
// i18n/serviceWorkerLocale.ts); the kept HTML needs that locale's catalog, and
// en under a partial one, in the asset cache, or an offline open would wait
// for a file it cannot get; en's alone while the locale is not known yet.
// Never every locale: one release would download all.
const LOCALE_CATALOG_MAP = /<script type="application\/json" id="raft-locale-catalogs">([^<]*)<\/script>/;
const DISPLAY_LOCALES = ["en", "es", "pt-br", "ko", "ja", "zh-cn", "zh-tw"];
const COMPLETE_LOCALES = ["en", "zh-cn"];
const DISPLAY_LOCALE_KEY = "/__raft/display-locale";
const BUILT_JS = /^\/assets\/[^"<>?#]+\.js$/;

function catalogMapOf(html) {
  const json = LOCALE_CATALOG_MAP.exec(html)?.[1];
  if (!json) return null;
  try {
    const map = JSON.parse(json);
    return map && typeof map === "object" ? map : null;
  } catch {
    return null;
  }
}

/** The catalog files `locale` is shown from, per the page's map; null when the map lacks one. */
function catalogPathsFor(map, locale) {
  const locales = COMPLETE_LOCALES.includes(locale) ? [locale] : [locale, "en"];
  const paths = locales.map((name) => map[name]);
  return paths.every((path) => typeof path === "string" && BUILT_JS.test(path)) ? paths : null;
}

async function displayLocale() {
  const stored = await (await caches.open(SHELL_CACHE)).match(DISPLAY_LOCALE_KEY);
  const locale = stored ? (await stored.text()).trim() : "";
  return DISPLAY_LOCALES.includes(locale) ? locale : null;
}

async function cacheAssets(paths) {
  const assets = await caches.open(ASSET_CACHE);
  for (const path of paths) {
    const url = new URL(path, self.location.origin).href;
    if (await assets.match(url)) continue;
    const asset = await fetch(url, { cache: "reload" });
    if (!isCacheableAssetResponse(new Request(url), asset)) return false;
    await assets.put(url, asset);
  }
  return true;
}

function isHtmlFallbackResponse(response) {
  return HTML_FALLBACK_CONTENT_TYPE.test(response.headers.get("content-type") || "");
}

function isCacheableAssetResponse(req, response) {
  if (!response.ok || response.redirected) return false;

  const contentType = (response.headers.get("content-type") || "").toLowerCase();
  if (isHtmlFallbackResponse(response)) return false;

  const url = new URL(req.url);
  if (CACHEABLE_ASSET_PATH.test(url.pathname)) return true;

  return CACHEABLE_ASSET_TYPES.some((type) => contentType.startsWith(type));
}

self.addEventListener("install", (event) => {
  event.waitUntil(self.skipWaiting());
});

function isAppNavigation(req, url) {
  return req.mode === "navigate"
    && url.origin === self.location.origin
    && !NOT_APP_PAGE.test(url.pathname)
    && !FILE_PATH.test(url.pathname);
}

// The cached HTML is served only while every file its first paint loads is in
// the asset cache: an old page whose files are gone from the server would stay blank.
async function usableShell() {
  const shell = await (await caches.open(SHELL_CACHE)).match(SHELL_KEY);
  if (!shell) return null;
  const savedAt = Number(shell.headers.get(SHELL_SAVED_AT) || 0);
  if (!(Date.now() - savedAt < SHELL_MAX_AGE_MS)) return null;
  const assets = await caches.open(ASSET_CACHE);
  const paths = (shell.headers.get(SHELL_ASSETS) || "").split(" ").filter(Boolean);
  if (paths.length === 0) return null;
  const map = catalogMapOf(await shell.clone().text());
  if (map) {
    const catalogs = catalogPathsFor(map, (await displayLocale()) ?? "en");
    if (!catalogs) return null;
    paths.push(...catalogs);
  }
  const present = await Promise.all(paths.map((path) => assets.match(new URL(path, self.location.origin).href)));
  return present.every(Boolean) ? shell : null;
}

// Keeps the HTML the network just sent, once the files its first paint loads
// are in the asset cache (fetched now if needed), so the next open can run it
// offline from the server. Returns "urgent" when the release asks to take
// effect at once, "kept" when it was kept, otherwise null.
async function keepShell(response) {
  if (!response.ok || response.redirected || !isHtmlFallbackResponse(response)) return null;
  // A public Artifact's page, rewritten for it by the Pages Worker (_worker.js
  // ARTIFACT_PREVIEW_HEADER): its title, preview tags and article belong to
  // that page alone, never the shell every page opens from.
  if (response.headers.has("x-raft-artifact-preview")) return null;
  const html = await response.text();
  const shellCache = await caches.open(SHELL_CACHE);
  if (!SHELL_MARKER.test(html) || !SHELL_ENTRY.test(html)) return null;
  if (SHELL_URGENT_META.test(html)) {
    await shellCache.delete(SHELL_KEY);
    return { verdict: "urgent", html };
  }
  const paths = [...new Set([...html.matchAll(SHELL_ASSET_REF)].map((match) => match[1]))];
  // A release with a catalog map is kept only with the display locale's
  // catalogs cached beside its files. Not knowing the locale yet (a page from
  // before the map never tells it), en's: the release is kept as usual, and
  // once it boots and tells its locale, the message handler below caches that
  // locale's catalogs for it.
  const map = catalogMapOf(html);
  let catalogs = [];
  if (map) {
    catalogs = catalogPathsFor(map, (await displayLocale()) ?? "en");
    if (!catalogs) return null;
  }
  if (!(await cacheAssets([...paths, ...catalogs]))) return null;
  const previous = await shellCache.match(SHELL_KEY);
  const headers = new Headers(response.headers);
  // The body is stored decoded.
  headers.delete("content-encoding");
  headers.delete("content-length");
  headers.set(SHELL_SAVED_AT, String(Date.now()));
  headers.set(SHELL_ASSETS, paths.join(" "));
  await shellCache.put(SHELL_KEY, new Response(html, { status: response.status, statusText: response.statusText, headers }));
  // The display locale's catalogs stay too: usableShell needs them offline.
  if (previous && previous.headers.get(SHELL_ASSETS) !== paths.join(" ")) {
    await dropOldReleaseAssets(await caches.open(ASSET_CACHE), [...paths, ...catalogs]);
  }
  return { verdict: "kept", html };
}

// A new release is kept: the asset cache drops every file the new HTML
// doesn't load at first paint, other than the display locale's catalogs. Without this each release left a whole set
// of files behind (only a cache-name bump cleared them). The new release's
// other files (routes loaded on demand) come back the next time they load
// (fillAssetCache); a page still open on the old release is told it was
// superseded and reloads onto the new one when a file fails.
async function dropOldReleaseAssets(assets, keptPaths) {
  const kept = new Set(keptPaths);
  const requests = await assets.keys();
  await Promise.all(
    requests
      .filter((request) => !kept.has(new URL(request.url).pathname))
      .map((request) => assets.delete(request)),
  );
}

// Tells the page that just opened from the kept HTML what the network said
// (main.tsx): "raft:shell-urgent", a release that must take effect at once;
// "raft:shell-superseded", a newer release is now kept. A superseded page's
// files loaded on demand may be gone from the server; it reloads onto the
// kept release when one fails instead of showing the refresh screen.
async function tellPage(clientId, type) {
  const client = clientId ? await self.clients.get(clientId) : null;
  client?.postMessage({ type });
}

function respondWithShell(event, url) {
  event.respondWith(
    (async () => {
      const shell = await usableShell().catch(() => null);
      if (shell) {
        const served = shell.clone();
        event.waitUntil(
          (async () => {
            const kept = await keepShell(await fetch(url.href, { cache: "no-store", credentials: "same-origin" }));
            if (kept?.verdict === "urgent") await tellPage(event.resultingClientId, "raft:shell-urgent");
            else if (kept?.verdict === "kept" && kept.html !== (await served.text())) {
              await tellPage(event.resultingClientId, "raft:shell-superseded");
            }
          })().catch(() => {}),
        );
        return shell;
      }
      try {
        const response = await fetch(event.request);
        event.waitUntil(keepShell(response.clone()).catch(() => {}));
        return response;
      } catch (error) {
        const offline = await (await caches.open(SHELL_CACHE)).match(SHELL_KEY).catch(() => null);
        if (offline) return offline;
        throw error;
      }
    })(),
  );
}

// The page's display locale (raft:display-locale): kept for the next HTML,
// and its catalogs for the HTML already kept, so a language switch works offline too.
self.addEventListener("message", (event) => {
  const data = event.data;
  if (!data || data.type !== "raft:display-locale" || !DISPLAY_LOCALES.includes(data.locale)) return;
  event.waitUntil?.((async () => {
    await (await caches.open(SHELL_CACHE)).put(DISPLAY_LOCALE_KEY, new Response(data.locale, { headers: { "content-type": "text/plain" } }));
    const shell = await (await caches.open(SHELL_CACHE)).match(SHELL_KEY);
    const map = shell ? catalogMapOf(await shell.text()) : null;
    const catalogs = map ? catalogPathsFor(map, data.locale) : null;
    if (catalogs) await cacheAssets(catalogs);
  })().catch(() => {}));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => (k.startsWith("slock-assets-") && k !== ASSET_CACHE) || (k.startsWith("slock-shell-") && k !== SHELL_CACHE))
          .map((k) => caches.delete(k)),
      );
      await self.clients.claim();
    })(),
  );
});

// Hashed build assets (immutable by Vite's content hash) are read from the
// browser's HTTP cache while online: the worker doesn't answer, so a warm
// open costs no worker round trip, and the HTTP cache keeps the compressed
// bytes (Cache Storage keeps them decoded: app-shell.js 3 MB against 850 KB),
// read in parallel instead of one caches.open/match after another (#proj-frontend,
// InNOut's warm-load timings: 68-451ms per file through the worker, 0-40ms without).
// The asset cache stays filled, in the background, for two jobs: the kept
// HTML is served only while its files are there (usableShell), and offline
// (the PWA resumed from disk after Android Chrome killed the backgrounded
// tab) the worker answers from it.
const ASSET_FILL_DELAY_MS = 5_000;

async function fillAssetCache(req) {
  const cache = await caches.open(ASSET_CACHE);
  if (await cache.match(req)) return;
  // After the page's own request has put it in the HTTP cache, so this reads
  // from disk rather than downloading the file a second time.
  await new Promise((resolve) => setTimeout(resolve, ASSET_FILL_DELAY_MS));
  if (await cache.match(req)) return;
  const response = await fetch(req, { cache: "force-cache" });
  if (isCacheableAssetResponse(req, response)) await cache.put(req, response);
}

async function assetFromCacheFirst(req) {
  const cache = await caches.open(ASSET_CACHE);
  const cached = await cache.match(req);
  if (cached) return cached;
  const response = await fetch(req, { cache: "reload" });
  if (response.ok && isHtmlFallbackResponse(response)) {
    return new Response("", { status: 404, statusText: "Not Found" });
  }
  if (isCacheableAssetResponse(req, response)) cache.put(req, response.clone()).catch(() => {});
  return response;
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (isAppNavigation(req, url)) {
    respondWithShell(event, url);
    return;
  }
  if (url.origin !== self.location.origin) return;
  if (!url.pathname.startsWith("/assets/")) return;

  if (self.navigator?.onLine !== false) {
    // Not answered: the browser loads it as if there were no worker.
    event.waitUntil(fillAssetCache(req).catch(() => {}));
    return;
  }
  event.respondWith(assetFromCacheFirst(req));
});

function isSameNotificationTarget(clientUrl, targetUrl) {
  try {
    const client = new URL(clientUrl);
    const target = new URL(targetUrl, self.location.origin);
    if (client.origin !== target.origin) return false;
    if (client.pathname !== target.pathname) return false;

    return client.searchParams.get("thread") === target.searchParams.get("thread");
  } catch {
    return false;
  }
}

function getPushNotificationData(event) {
  if (!event.data) return {};

  let text;
  try {
    text = event.data.text();
  } catch {
    return {
      title: "Raft",
      body: "New activity",
    };
  }

  if (!text) return {};

  try {
    return JSON.parse(text);
  } catch {
    return {
      title: "Raft",
      body: text,
    };
  }
}

self.addEventListener("push", (event) => {
  const data = getPushNotificationData(event);

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
      const targetUrl = data.url || "/";
      const shouldSuppress = !data.alwaysShow && clients.some((client) => {
        const isActive = client.focused || client.visibilityState === "visible";
        return isActive && isSameNotificationTarget(client.url, targetUrl);
      });
      if (shouldSuppress) return;

      return self.registration.showNotification(data.title || "Raft", {
        body: data.body || "New activity",
        icon: "/android-chrome-192x192.png",
        badge: "/favicon-32x32.png",
        tag: data.tag || "slock-push",
        data: { url: targetUrl },
      });
    }),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  const targetUrl = event.notification?.data?.url || "/";

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(async (clients) => {
      const matchingClient = clients.find((client) => isSameNotificationTarget(client.url, targetUrl));
      if (matchingClient) {
        matchingClient.postMessage({ type: "RAFT_PUSH_NOTIFICATION_NAVIGATE", url: targetUrl });
        await matchingClient.focus();
        return;
      }
      await self.clients.openWindow(targetUrl);
    }),
  );
});
