import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-0FBnJYne.js";import"./chunk-DU6HZSFF-D3G25mE3.js";import"./chunk-75Z2AOVW-odU1APaS.js";import"./chunk-PWAF6VOD-TmgtG5xw.js";import"./chunk-GMAD6QVW-D0LUrf3l.js";import"./chunk-P2QGCYS3-FTZ56zRL.js";import"./chunk-4HAMMTFA-Cr4Qq1pk.js";import"./chunk-GVQU2GXP-uVPcDrgv.js";import"./chunk-OSK3NFVY-BKHYT-N9.js";import"./chunk-F27PBJKO-CJeejip_.js";import"./chunk-XXDRQBXY-BMlMjiG2.js";import"./chunk-POPQ4Y6H-CJExo9f1.js";import"./chunk-L3NEJ4N5-BlIHk6fA.js";import{r as t,t as n}from"./chunk-SHT3W25Y-BGw7DITu.js";import"./mermaid.core-BmcT1daZ.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};